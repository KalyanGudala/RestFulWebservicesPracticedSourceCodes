insert into user values(10001,sysdate(),'Om');
insert into user values(10002,sysdate(),'Sri');
insert into user values(10003,sysdate(),'Sachithananda');
insert into user values(1004,sysdate(),'SadguruSai');
insert into post values(11001,'My First Post JPA',10001);
insert into post values(11002,'My Second Post JPA',10001);